-- AlterTable
ALTER TABLE `customer` ADD COLUMN `Uploaded_Files` VARCHAR(191) NULL;
