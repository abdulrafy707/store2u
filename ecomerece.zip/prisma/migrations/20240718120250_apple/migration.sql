-- AlterTable
ALTER TABLE `subcategory` ADD COLUMN `imageUrl` VARCHAR(191) NULL;
